//import org.jsoup.nodes.Element;

import org.openqa.selenium.By;
//import org.openqa.selenium.Point;
//import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import java.util.List;
import java.util.Queue;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class Automation {
    public static void main(String[] args) {
        String user = "", password = "";
        Scanner scann = new Scanner(System.in);
        System.out.println("enter your username");
        user = scann.next();
        System.out.println("enter your password");
        password = scann.next();


        System.setProperty("webdriver.chrome.driver", "C:\\Users\\uriel\\Desktop\\chromedriver.exe");

        ChromeDriver driver = new ChromeDriver();
        driver.get("https://www.aac.ac.il/");
        driver.manage().window().maximize();
        WebElement connection = driver.findElement(By.cssSelector("a[href='https://portal.aac.ac.il']"));
        connection.click();
        WebElement elementUser = driver.findElement(By.id("Ecom_User_ID"));
        elementUser.sendKeys("" + user);
        WebElement elementPassword = driver.findElement(By.id("Ecom_Password"));
        elementPassword.sendKeys("" + password);
        WebElement elementLogin = driver.findElement(By.id("wp-submit"));
        elementLogin.click();
        WebElement moodle = driver.findElement(By.cssSelector("a[href='https://moodle.aac.ac.il/login/index.php']"));
        moodle.click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        WebElement courseListPerent = driver.findElement(By.cssSelector("div[role ='list']"));
     //   List<WebElement> courseList2 = courseListPerent.findElements(By.cssSelector("div"));
        List<WebElement> courseList = courseListPerent.findElements(By.cssSelector("h6"));
        // all courses names in h6
     /*   for (WebElement element:courseList) {
            String text = element.getText();
            System.out.println(text);
        }*/
        for (WebElement element:courseList) {
            String text = element.getText();
            System.out.println(text);
        }
        System.out.println(" end");
    }
}